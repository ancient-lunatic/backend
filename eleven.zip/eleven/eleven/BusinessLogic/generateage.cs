﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eleven.BusinessLogic
{
    public class generateage
    {

        /*
        public string differentBtwAge(DateTime oldDate)
        {
            DateTime zeroTime = new DateTime(1, 1, 1);
            DateTime curdate = DateTime.Now.ToLocalTime();
            TimeSpan span = curdate - oldDate;
            int years = (zeroTime + span).Year - 1;
            int months = (zeroTime + span).Month - 1;
            int days = (zeroTime + span).Day - 1;
            return new AgePrams(days, months, years);
                } }

        public class AgePrams
        {
            public int Years { get; set; }
            public int Months { get; set; }
            public int Days { get; set; }
            public AgePrams(int a, int b, int c)
            {
                Days = a;
                Months = b;
                Years = c;
            }
            public string ToString()
            {
                return this.Years + " years " + Months + " months";
            }

        }*/
    }
}
