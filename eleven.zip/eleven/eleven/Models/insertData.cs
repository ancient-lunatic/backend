﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eleven.Models
{
    public class insertData
    {

        public int salutation { get; set; }
        public string firstName { get; set; }
        public string MiddleName { get; set; }
        public string lastName { get; set; }
        public int gender { get; set; }
        public int nationality { get; set; }
        public DateTime date { get; set; }
        public string addressLine1 { get; set; }
        public string addressLine2 { get; set; }
        public string Locality { get; set; }
        public int city { get; set; }
        public string contact { get; set; }
    }
}
